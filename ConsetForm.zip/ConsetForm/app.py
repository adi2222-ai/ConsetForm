import json
import os

from flask import Flask, render_template, request, redirect, url_for, session

app = Flask(__name__)
app.secret_key = "your_secret_key"  # Replace with your own secret key

PATIENTS_FILE = "patients.json"
PATIENTS_CONSENT = "data/mrconsent.json"  # Specify the full path


def save_patient_data(patient_data):
    if not os.path.exists(PATIENTS_FILE):
        with open(PATIENTS_FILE, "w") as patients_file:
            json.dump([], patients_file)

    with open(PATIENTS_FILE, "r") as patients_file:
        patients_list = json.load(patients_file)

    patients_list.append(patient_data)

    with open(PATIENTS_FILE, "w") as patients_file:
        json.dump(patients_list, patients_file, indent=4)


@app.route("/")
def welcome():
    return render_template("welcome.html")


@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        username = request.form["username"]
        password = request.form["password"]
        confirm_password = request.form["confirm_password"]

        if password == confirm_password:
            with open("users.json", "r") as existing_users_file:
                existing_users = json.load(existing_users_file)
                if username not in existing_users:
                    existing_users[username] = {"password": password}
                    with open("users.json", "w") as new_users_file:
                        json.dump(existing_users, new_users_file)
                    return redirect(url_for("login"))
                else:
                    return "Username already exists. Please choose another username."
        else:
            return "Passwords do not match. Please try again."

    return render_template("register.html")


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form["username"]
        password = request.form["password"]

        with open("users.json", "r") as users_file:
            users = json.load(users_file)
            if username in users and users[username]["password"] == password:
                session["username"] = username
                return redirect(url_for("form_page"))  # Redirect to form_page route
            else:
                return "Invalid credentials. Please try again."

    return render_template("login.html")


@app.route("/form_page")
def form_page():
    return render_template("form_page.html")


@app.route("/search_page")
def search_page():
    return render_template("search.html")

@app.route("/search_consent")
def search_consent():
    return render_template("search_consent")

@app.route("/choose_modality")
def choose_modality():
    patient_info = {}  # Placeholder for patient information

    return render_template("choose_modality.html", patient_info=patient_info)


@app.route("/search_results")
def search_results():
    search_mrn = request.args.get("search")

    with open(PATIENTS_FILE, "r") as patients_file:
        patients_list = json.load(patients_file)

    matched_patients = [patient for patient in patients_list if patient["mrn"] == search_mrn]

    return render_template("search_results.html", matched_patients=matched_patients)

@app.route("/search_consent_results")
def search_consent_results():
    search_query = request.args.get("search").lower()  # Convert search query to lowercase for case-insensitive search

    with open(PATIENTS_CONSENT, "r") as consent_file:
        consent_data = json.load(consent_file)

    matched_consent_records = []

    for record in consent_data:
        for key, value in record.items():
            if search_query in str(value).lower():  # Convert value to string and perform case-insensitive search
                matched_consent_records.append(record)
                break  # Break after finding a match in any key-value pair

    return render_template("search_consent_results.html", matched_consent_records=matched_consent_records)


@app.route('/MRI_conser.html', methods=['GET', 'POST'])
def mriconsent():
    if request.method == 'POST':
        mrconsent = {
            "patient-id": request.form["patient_id"],
            "institution-name": request.form["institution_name"],
            "patient-name": request.form["patient_name"],
            "dob": request.form["dob"],
            "procedure-date": request.form["procedure_date"],
            "consent-given": request.form["consent-given"]  # Updated field name
            # Add more fields as needed
        }

        # Save the mrconsent data to a JSON file
        data_dir = "data"  # Replace with your desired directory path
        if not os.path.exists(data_dir):
            os.makedirs(data_dir)
        file_path = os.path.join(data_dir, "mrconsent.json")

        if os.path.exists(file_path):
            with open(file_path, "r") as json_file:
                try:
                    consent_data = json.load(json_file)
                except json.JSONDecodeError:
                    consent_data = []
        else:
            consent_data = []

        consent_data.append(mrconsent)

        with open(file_path, "w") as json_file:
            json.dump(consent_data, json_file, indent=4)

        return "MRI Consent Form submitted successfully!"

    return render_template("mri_consent.html")


@app.route('/patient_registration', methods=['GET', 'POST'])
def patient_registration():
    if request.method == 'POST':
        patient_data = {
            "mrn": request.form["mrn"],
            "full_name": request.form["full_name"],
            "email": request.form["email"],
            "phone": request.form["phone"],
            "gender": request.form["gender"],
            "weight": request.form["weight"],
            "pregnant": request.form["pregnant"],
            "dob": request.form["dob"]
        }

        save_patient_data(patient_data)
        return "Patient registered successfully!"

    elif request.method == 'GET' and 'search' in request.args:
        search_mrn = request.args['search']

        with open(PATIENTS_FILE, "r") as patients_file:
            patients_list = json.load(patients_file)

        matched_patients = [patient for patient in patients_list if patient["mrn"] == search_mrn]

        return render_template("search_results.html", matched_patients=matched_patients)

    return render_template("register_patient.html")


@app.route('/MRI_consent')
def mri_consent():
    return render_template('MRI_consent.html')


@app.route('/CT_consent')
def ct_consent():
    return render_template('CT_consent.html')


@app.route('/Xray_consent')
def xray_consent():
    return render_template('Xray_consent.html')


@app.route('/US_consent')
def us_consent():
    return render_template('US_consent.html')


if __name__ == "__main__":
    app.run(debug=True)
